package databases_connect;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class InsertForm implements ActionListener {
	JButton login=new JButton("Login");
	JTextField user;
	JPasswordField pw;
	JPanel p1,p2,p3;
	
public InsertForm() {
	JFrame f=new JFrame("Login Form");
	user =new JTextField();
	user.setPreferredSize(new Dimension(100,30));
	pw=new JPasswordField();
	pw.setPreferredSize(new Dimension(100,30));
	p2=new JPanel();
	p2.add(new JLabel("Password"));
	p2.add(pw);
	
	p1=new JPanel();
	p1.add(new JLabel("User Name"));
	p1.add(user);
	p3=new JPanel();
	p3.add(login);
	login.addActionListener(this);
	f.add(p3);
	f.add(p1);
	f.add(p2);
	f.setSize(300,200);
	f.setVisible(true);
	f.setLocation(600,200);
	f.setLayout(new BoxLayout(f.getContentPane(),BoxLayout.Y_AXIS));
	f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
	
	
}
public static void main(String[] args) {
	new InsertForm();
}
@Override
public void actionPerformed(ActionEvent e) {
	Connection con;
	java.sql.Statement stm;
	try {
		
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/GUIDb","root","creation11111");
		//JOptionPane.showMessageDialog(null, "Connection Successful");
		stm=con.createStatement();
		String query="insert into dbuser (username,password) values(?,?)";
		PreparedStatement ps=con.prepareStatement(query);
		ps.setString(1, user.getText());
		ps.setString(2, pw.getText());
		ps.executeUpdate();
		JOptionPane.showMessageDialog(null, "Insert Success");
		ResultSet rs=stm.executeQuery("Select * from dbuser");
		String uname=user.getText();
		String password =pw.getText();
		System.out.println("User Name"+"\t"+"Password");
		while(rs.next()) {
			System.out.println(rs.getString(1)+"\t\t"+rs.getString(2));
		}
		user.setText("");
		pw.setText("");
	} catch (Exception e2) {
		e2.printStackTrace();
	}
	
}
	
}

