package databases_connect;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class UpdateForm implements ActionListener {
	
	JTextField user,upname;
	JPasswordField pw;
	JPanel p1,p2,p3;
	JButton Update1=new JButton("Update");
	JButton show=new JButton("Show");
public UpdateForm() {
	JFrame f=new JFrame("Update Form");
	user =new JTextField();
	user.setPreferredSize(new Dimension(100,30));
	pw=new JPasswordField();
	pw.setPreferredSize(new Dimension(100,30));
	p2=new JPanel();
	p2.add(new JLabel("Password"));
	p2.add(pw);
	
	upname=new JTextField();
	upname.setPreferredSize(new Dimension(100,30));
    JPanel pup=new JPanel();
    pup.add(new JLabel("Set Name"));
    pup.add(upname);
    
	p1=new JPanel();
	p1.add(new JLabel("User Name"));
	p1.add(user);
	p3=new JPanel();
	p3.add(Update1);
	p3.add(show);
	Update1.addActionListener(this);
	show.addActionListener(this);
	f.add(p1);
	f.add(p2);
	f.add(pup);
	f.add(p3);
	
	f.setSize(300,200);
	f.setVisible(true);
	f.setLocation(600,200);
	f.setLayout(new BoxLayout(f.getContentPane(),BoxLayout.Y_AXIS));
	f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
public static void main(String[] args) {
	new UpdateForm();
}
@Override
public void actionPerformed(ActionEvent e) {
	Connection con;
	Statement stm;
	PreparedStatement ps;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/GUIDb","root","creation11111");
		stm=con.createStatement();
		//JOptionPane.showMessageDialog(null, "Connection Successful");
		if(e.getSource()==Update1) {
			String query="Update dbuser set username=?,password=? where username=?";
			ps=con.prepareStatement(query);
			ps.setString(1, user.getText());
			ps.setString(2, pw.getText());
			ps.setString(3, upname.getText());
			ps.executeUpdate();
			JOptionPane.showMessageDialog(null, "Update Successful");
			user.setText("");
			pw.setText("");
			upname.setText("");
			
			
			
		}
		if(e.getSource()==show) {
			stm=con.createStatement();
			ResultSet rs=stm.executeQuery("select * from dbuser");
			while(rs.next()) {
				System.out.println(rs.getString(1)+"\t"+rs.getString(2));
				
			}
		
		}
		
	} catch (Exception e2) {
		e2.printStackTrace();
	}
	
}
}
