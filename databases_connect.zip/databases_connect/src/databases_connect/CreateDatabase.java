package databases_connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class CreateDatabase {
	

public static void main(String[] args) {
     Connection cnt=null;
try {
	Class.forName("com.mysql.cj.jdbc.Driver");
	cnt=DriverManager.getConnection("jdbc:mysql://localhost:3306","root", "creation11111");
	System.out.println("Connection Success!!!");
	Statement stm=cnt.createStatement();
	//stm.execute("create database javaDB");
	System.out.println("create database successfully");
	stm.execute("use javadb");
	System.out.println("Database usages javadb");
} catch (Exception e) {
	System.out.println("Error Connection"+e);
}

}
}
