package databases_connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class AllAboutJDBC {
public static void main(String[] args) {
	Connection con=null;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","creation11111");
		System.out.println("success");
		Statement stm=con.createStatement();	
		//create database
		//stm.execute("create database AllAboutJDBC");
		//stm.execute("use ALLAboutJDBC");
		//create table
		//stm.execute("create table test(id int primary key,name varchar(30),salary decimal(0,2)");
		
		System.out.println("success create table");
		//stm.executeUpdate("insert into test values(101,'Army Fan',123.00),(102,'Messi',223.00)");
		//stm.executeUpdate("update test set name='Army' where id=101");
		stm.executeUpdate("delete from test where id=101");
		ResultSet rs=stm.executeQuery("select * from test");
		while (rs.next()) {
			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getDouble(3));
		}
	} catch (Exception e) {
		System.out.println("Connection fail"+e);
	}
}
}
