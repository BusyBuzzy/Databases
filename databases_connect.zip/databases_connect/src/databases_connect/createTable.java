package databases_connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class createTable {
public static void main(String[] args) {
	Connection con=null;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/javadb","root","creation11111");
		//System.out.println("Connection success::::");
		Statement stm=con.createStatement();
		stm.execute("create table tabletest(id int primary key,Name varchar(30))");
		System.out.println("create table success");
		} catch (Exception e) {
		System.out.println("connect fail"+e); 
	}
}
}
