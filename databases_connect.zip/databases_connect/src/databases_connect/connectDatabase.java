package databases_connect;

import java.sql.Connection;
import java.sql.DriverManager;

public class connectDatabase {
	public static void main(String[] args) {
		Connection con=null;
		try {
			//call driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","creation11111");
			System.out.println("Connection Successfully");
			
			
		} catch (Exception e) {
			System.out.println("Connection Error"+e);
		}
	}
}
