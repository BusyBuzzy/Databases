package databases_connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DeleteData {
public static void main(String[] args) {
	Connection con =null;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/javadb","root","creation11111");
		System.out.println("Success");
		Statement stm=con.createStatement();
		String query="delete from tabletest where id=5";
		stm.executeUpdate(query);
		System.out.println("Delete success");
		ResultSet rs=stm.executeQuery("select * from tabletest");
		while(rs.next()) {
			System.out.println(rs.getInt(1)+""+rs.getString(2));
		}
	} catch (Exception e) {
		System.out.println("Connection fail"+e);
	}
}
}
