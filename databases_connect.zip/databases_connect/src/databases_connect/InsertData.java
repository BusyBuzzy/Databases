package databases_connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class InsertData {
public static void main(String[] args) {
	Connection con=null;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/javadb","root","creation11111");
		Statement stm=con.createStatement();
		String sql="insert into tabletest values(4,'kee')";
		stm.executeUpdate(sql);
		System.out.println("Insert success");
		ResultSet rs=stm.executeQuery("Select * from tabletest");
		while(rs.next()) {
			System.out.println(rs.getInt("id")+"\t"+rs.getString("Name"));
			System.out.println();
		}
	} catch (Exception e) {
		System.out.println("Connect Fail");
	}
}
}
