package databases_connect;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class preparestatementUse {
public static void main(String[] args) {
	Connection con=null;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/javadb","root","creation11111");
		System.out.println("Success");
		Statement stm=con.createStatement();		
		/*Scanner sc=new Scanner(System.in);
		System.out.println("Enter a ID start from 4: ");
		int id=sc.nextInt();
		System.out.println("Enter Name: ");
		String name=sc.next();*/
		String query="insert into tabletest values(?,?)";
		PreparedStatement pre=con.prepareStatement(query);	
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		char ch='n';
		do {
			System.out.println("Enter ID: ");
			int id=Integer.parseInt(br.readLine());
			System.out.println("");
			System.out.println("Do you want to continue y/n");
			
			String name=br.readLine();
			ch=br.readLine().charAt(0);
			pre.setInt(1, id);
			pre.setString(2, name);
			pre.executeUpdate();
		} while (ch!='n');
		
		System.out.println("Insert success");
		ResultSet rs=stm.executeQuery("select * from tabletest");
		while(rs.next()) {
			System.out.println(rs.getInt(1)+""+rs.getString(2));
		}
		
		} catch (Exception e) {
		System.out.println("Connection fail"+e);
	}
	
}
}
