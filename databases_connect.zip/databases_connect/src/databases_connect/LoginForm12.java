package databases_connect;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class LoginForm12 extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JTextField user;
	private JPasswordField pw;

	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginForm12 frame = new LoginForm12();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginForm12() {
		setTitle("Login Form");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 390, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("User Name");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel.setBounds(26, 53, 89, 28);
		contentPane.add(lblNewLabel);
		
		user = new JTextField();
		user.setBounds(125, 59, 120, 21);
		contentPane.add(user);
		user.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(26, 123, 89, 28);
		contentPane.add(lblNewLabel_1);
		
		pw = new JPasswordField();
		pw.setBounds(125, 130, 120, 21);
		contentPane.add(pw);
		pw.setColumns(10);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnNewButton.setBounds(125, 185, 107, 43);
		contentPane.add(btnNewButton);
		btnNewButton.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Connection con;
		java.sql.Statement stm;
		try {
			
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/GUIDb","root","creation11111");
			//JOptionPane.showMessageDialog(null, "Connection Successful");
			stm=con.createStatement();
			ResultSet rs=stm.executeQuery("select * from dbuser");
			String uname=user.getText();
			String password =pw.getText();
			while(rs.next()) {
				if(rs.getString(1).equals(uname)&& rs.getString(2).equals(password)) {
				JOptionPane.showMessageDialog(null, "SUccess Message");
			
			}else {
				JOptionPane.showMessageDialog(null, "dinied Message");
			}
			}
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		
	}
}
