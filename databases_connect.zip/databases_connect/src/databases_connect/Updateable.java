package databases_connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Updateable {
public static void main(String[] args) {
	Connection con=null;
	
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/javadb","root","creation11111");
		System.out.println("Success connect");
		Statement stm=con.createStatement();		
		stm.executeUpdate("update tabletest set Name='Mg Mg' where id=2");
		ResultSet rs=stm.executeQuery("select * from tabletest");
		while(rs.next()) {
			System.out.println(rs.getInt(1)+" "+rs.getString(2));
		}
		con.close();
	} catch (Exception e) {
		System.out.println("Connection fail"+e);
	}
}
}
