package databases_connect;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ActorProfile implements ActionListener {
	JTextField fname,lname;
	JButton query=new JButton("Query");
	JTextArea area=new JTextArea();
public ActorProfile() {
	JFrame f=new JFrame("Actor Profile");
	JLabel l1=new JLabel("Actor Profile");
	l1.setFont(new Font("Time New Roman",Font.BOLD,14));
	JPanel p1=new JPanel();
	p1.add(l1);
	
	fname=new JTextField();
	fname.setPreferredSize(new Dimension(100, 30));
	lname=new JTextField();
	lname.setPreferredSize(new Dimension(100, 30));
	JPanel p2=new JPanel();
	
	p2.add(new JLabel("First Name"));
	p2.add(fname);
	p2.add(new JLabel("Last Name"));
	p2.add(lname);
	p2.add(query);
	query.addActionListener(this);
	area.setPreferredSize(new Dimension(500, 150));
	JPanel p3=new JPanel();
	area.setText("Actor Id\tFirstName\t\tLastName\t\tLast Updated");
	p3.add(area);
	f.add(p1);
	f.add(p2);
	f.add(p3);
	
	f.setSize(600, 300);
	f.setLayout(new BoxLayout(f.getContentPane(), BoxLayout.Y_AXIS));
	f.setVisible(true);
	f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
public static void main(String[] args) {
	new ActorProfile();
}
@Override
public void actionPerformed(ActionEvent e) {
	Connection con;
	Statement stm;
	PreparedStatement ps;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","creation11111");
		stm=con.createStatement();
		//stm.execute("create database Actor");
		stm.execute("use Actor");
		stm.execute("create table ");
		JOptionPane.showMessageDialog(null, "Success");
	} catch (Exception e2) {
		e2.printStackTrace();
	}
	
}
}
