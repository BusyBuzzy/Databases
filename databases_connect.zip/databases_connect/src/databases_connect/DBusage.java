package databases_connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;



public class DBusage {
public static void main(String[] args) {
	dbConnection();
	
}

private static void dbConnection() {
	Connection con;
	Statement stm;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","creation11111");
		System.out.println("success");
		stm=con.createStatement();
		//stm.execute("create database GUIDb");
System.out.println("DataBases GUIDb haas created");
		stm.execute("use GUIDb");
		System.out.println("GUIDb is selected");
		//stm.execute("create table dbuser(username varchar(50),password varchar(50));");
		//String query="insert into dbuser values('wai','1234'),('yan','4321');";
		//stm.executeUpdate(query);
		ResultSet rs=stm.executeQuery("select * from dbuser;");
        while(rs.next()) {
        	System.out.println(rs.getString(1)+"\t"+rs.getString(2));
        }
		System.out.println("");
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
}
