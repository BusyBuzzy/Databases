package databases_connect;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class DeleteForm extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JTextField uname;
	JButton show,delete;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DeleteForm frame = new DeleteForm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DeleteForm() {
		setTitle("Delete Form");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Delete Name");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel.setBounds(26, 25, 108, 27);
		contentPane.add(lblNewLabel);
		
		uname = new JTextField();
		uname.setFont(new Font("Tahoma", Font.PLAIN, 16));
		uname.setBounds(164, 25, 148, 27);
		contentPane.add(uname);
		uname.setColumns(10);
		
		delete = new JButton("Delete");
		delete.setFont(new Font("Tahoma", Font.BOLD, 16));
		delete.setBounds(95, 141, 108, 41);
		contentPane.add(delete);
		
		show = new JButton("Show");
		show.setFont(new Font("Tahoma", Font.BOLD, 16));
		show.setBounds(241, 141, 108, 41);
		contentPane.add(show);
		
		delete.addActionListener(this);
		show.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Connection con;
		Statement stm;
		PreparedStatement ps;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/GUIDb","root","creation11111");
			stm=con.createStatement();
			if(e.getSource()==delete) {
				String query="delete from dbuser where username=?";
				ps=con.prepareStatement(query);
				ps.setString(1, uname.getText());
				ps.executeUpdate();
				JOptionPane.showMessageDialog(null, "Delete Success");
				uname.setText("");
			}
			if(e.getSource()==show) {
				ResultSet rs=stm.executeQuery("select * from dbuser");
				System.out.println("Username"+"\t"+"Password");
				while(rs.next()) {
					System.out.println(rs.getString(1)+"\t\t"+rs.getString(2));
				}
			}
		} catch (Exception e2) {

   e2.printStackTrace();
		}
		
	}

}
