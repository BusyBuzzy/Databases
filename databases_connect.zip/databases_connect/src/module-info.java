/**
 * 
 */
/**
 * @author user
 *
 */
module databases_connect {
	requires java.sql;
	requires java.desktop;
}